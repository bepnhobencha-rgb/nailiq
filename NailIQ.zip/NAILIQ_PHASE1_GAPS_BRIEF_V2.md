# NailIQ Phase 1 — Core Booking Completion Brief (v2)

> **For:** Claude Code in Cursor IDE
> **Project:** NailIQ (nailiq.ca)
> **Date:** May 22, 2026 (UPDATED)
> **Version:** 2.0 — replaces GAP 1 with Smart Verification approach
> **Status:** 9 of 10 GAPS implemented. GAP 1 superseded by Smart Verification.

---

## 0. CHANGELOG from v1

**Major change:** GAP 1 (Two-phase SMS Confirmation with Twilio webhooks) has been **REPLACED** by a stronger approach: **Smart Booking Verification** that intelligently combines OTP and deposit based on risk score.

**Why:** Audit revealed NailIQ already has both OTP infrastructure (`phone_otp_sessions`) and deposit infrastructure (`bookings.deposit_*`). Two-phase SMS tracking would have been duplicate work. OTP is stronger than delivery confirmation (proves customer SAW the SMS, not just that it was delivered). Deposit is stronger still (financial commitment).

**See:** `docs/NAILIQ_SMART_VERIFICATION_SPEC.md` for the new approach.

---

## 1. Infrastructure recap

```
Supabase project ID:    fshmobzyjhmtvndobwsy
Vercel project ID:      prj_1yP37n3CAzbk5BaXizY5TWcOa7gV
Production:             https://nailiq.ca
Framework:              Next.js, Node 24.x
Total tables:           34 (and counting)
Existing OTP infra:     otps, phone_otp_sessions, salons.phone_otp_enabled
Existing deposit infra: bookings.deposit_required, deposit_amount_cents, deposit_status
```

---

## 2. Updated GAP status (as of May 22, 2026)

| # | GAP | v1 Status | v2 Status | Notes |
|---|---|---|---|---|
| **1** | ~~Two-phase SMS~~ → **Smart Verification** | ⚠️ Partial (fire-and-forget) | 🔄 **Replace with Smart Verification** | See spec doc |
| 2 | Reference Image Upload | ✅ Done | ✅ Done | `bookings.reference_image_path` column added |
| 3 | Voucher Code Apply | ✅ Done | ✅ Done | TypeScript API routes at `/api/vouchers/{validate,redeem}` |
| 4 | AI Chatbot Booking | ✅ Done | ✅ Done | Enterprise tier only |
| 5 | AI Slot Ranking | ✅ Done | ✅ Done | API route, statistical (no ML) |
| 6 | Service Combos | ✅ Done | ✅ Done | `service_combos` table |
| 7 | QR Code | ✅ Done | ✅ Done | Generated runtime from booking ID |
| 8 | Auto Re-confirm | ✅ Done | ✅ Done | Cron `auto-reconfirm-daily` 8:00 AM |
| 9 | No-show Risk Score | ✅ Already existed | ✅ Existed | `bookings.no_show_risk_score` column |
| 10 | AI Image Recognition | ✅ Already existed | ✅ Existed | Via Claude vision in `photo-enhance` |

**Total: 9/10 done, 1 (Smart Verification) pending implementation**

---

## 3. Smart Verification — replaces GAP 1

### Decision logic

For each booking, choose ONE verification method based on customer + risk:

```
Booking submitted
  ↓
Compute risk score (existing no_show_risk_score logic)
  ↓
Apply decision tree:

┌─────────────────────────────────────────────────────────────┐
│ Customer State              │ Risk    │ Action              │
├─────────────────────────────┼─────────┼─────────────────────┤
│ is_vip = true               │ Any     │ ✅ None             │
│ Repeat (5+ visits, 0 no-shw)│ Any     │ ✅ None             │
│ New customer                │ < 30    │ ✅ None             │
│ Any                         │ 30-69   │ 🔵 OTP optional    │
│ Any + high-value booking    │ 70-100  │ 💰 Deposit required │
│ Any + low-value booking     │ 70-100  │ 🔴 OTP required     │
│ no_show_count >= 3          │ Any     │ 💰 Deposit or 🔴 OTP│
└─────────────────────────────┴─────────┴─────────────────────┘
```

### Customer never sees both OTP AND deposit. They serve the same purpose.

### Salon owner overrides

```
Verification Mode (salon settings):
  ( ) never              - Trust everyone (no friction, no protection)
  (•) auto               - Smart logic above (recommended)
  ( ) always_otp         - Force OTP for every booking
  ( ) always_deposit     - Force deposit for every booking
  ( ) deposit_first      - Try deposit, fallback to OTP
```

### What gets built

1. **Database migration** — add columns to `salons` + `bookings` (see spec)
2. **RPC functions** — `determine_booking_verification`, `compute_no_show_risk`, `confirm_booking_with_otp`
3. **Frontend** — verification step in booking flow with 5 different UIs
4. **Reception dashboard** — badges for SMS failures + verification status
5. **Owner settings** — verification mode selector
6. **Analytics** — no-show rate by verification method
7. **Cron job** — release abandoned pending bookings after 15 min

### Lightweight SMS fix (still part of this work)

Even with Smart Verification, fix the original fire-and-forget SMS:

```typescript
// Change in submitPublicBooking.ts
const smsResult = await sendSmsReminder(...);  // await instead of fire-forget
await updateBooking(bookingId, {
  sms_confirmation_sent_at: smsResult.ok ? new Date() : null,
  sms_confirmation_failed_at: smsResult.ok ? null : new Date(),
  sms_confirmation_error: smsResult.ok ? null : smsResult.error,
});
```

Show ⚠ badge on reception dashboard for failed SMS bookings.

---

## 4. Existing GAPS implementations (for reference)

Documented per Claude Code audit:

### GAP 2: Reference Image Upload
- Column `bookings.reference_image_path` (single image, not array)
- Storage bucket: `booking-references` 
- Component: image upload step in booking flow
- **Note:** spec called for 1-5 images; actual implementation is 1 image. Acceptable for v1.

### GAP 3: Voucher Code Apply
- File: `src/app/api/vouchers/validate/route.ts` (POST, validates voucher)
- File: `src/app/api/vouchers/redeem/route.ts` (POST, redeems after booking)
- TypeScript logic (not SQL RPCs as spec suggested)
- Idempotent on `(voucher_id, booking_id)`
- Discount computed server-side (anti-tampering)

### GAP 4: AI Chatbot
- Uses `ai_chats` table for conversation storage
- Enterprise tier only (salon Huy Tran has it enabled)
- Function calling with Claude API

### GAP 5: AI Slot Ranking
- File: `src/app/api/booking/slot-ranking/route.ts`
- Queries last 500 bookings in 90 days
- Tally by time-of-day label in salon timezone
- Returns top-3 popular labels
- **Note:** statistical only, not ML. Sufficient for Phase 1.

### GAP 6: Service Combos
- Table `service_combos` with: id, salon_id, name, description, service_ids[], price_cents, discount_cents, duration_minutes, is_active, position
- Admin CRUD via `/admin/services/combos`
- Public booking shows combos in dedicated section

### GAP 7: QR Code
- File: `src/components/booking/BookingFlowDonePanel.tsx:278`
- Uses `qrcode.react` library
- Encodes runtime-generated `#NQ-A1B2C3D4` (8-char from booking UUID)
- No `short_code` column needed
- Reception scans → reads ref → looks up booking

### GAP 8: Auto Re-confirm
- Column `bookings.reconfirm_sent_at`
- Cron job: `auto-reconfirm-daily` at 8:00 AM
- Sends 2nd reminder SMS if no `confirmed_at` 12h before start

### GAP 9: No-show Risk Score
- Column `bookings.no_show_risk_score` (existed before)
- Computation logic: TBD verify with Claude Code
- Used by Smart Verification (this brief)

### GAP 10: AI Image Recognition
- Implemented in `photo-enhance` Edge Function
- Uses Claude vision on uploaded reference images
- Returns detected style/colors/services

---

## 5. Acceptance criteria for Smart Verification

- [ ] `determine_booking_verification` RPC returns correct action for all 5 decision paths
- [ ] VIP customers (`is_vip=true`) never see OTP or deposit
- [ ] Risk < 30 → no verification (zero friction)
- [ ] Risk 30-69 → OTP optional (skippable with warning)
- [ ] Risk 70+ + high-value → deposit required
- [ ] Risk 70+ + low-value → OTP required
- [ ] `no_show_count >= 3` → force deposit or OTP
- [ ] OTP reuses existing `phone_otp_sessions` flow
- [ ] Deposit reuses existing Stripe Connect flow
- [ ] SMS confirmation tracked (`sms_confirmation_sent_at`, `failed_at`, `error`)
- [ ] Reception sees ⚠ for SMS failures + verification status badges
- [ ] Owner can switch mode via settings (Pro+ only for `auto`)
- [ ] Analytics shows no-show rate by verification method
- [ ] Cron releases abandoned pending bookings after 15 min
- [ ] No regression on existing booking flow (E2E suite passes)

---

## 6. Deploy strategy

1. **Database migration first** — non-breaking, all columns nullable/default
2. **Deploy RPCs** — `compute_no_show_risk` + `determine_booking_verification`
3. **Deploy frontend** with feature flag `smart_verification_enabled=false` on all salons
4. **Enable on THAO VY** (test salon), monitor 7 days
5. **Enable on LIAM NAILS**, monitor 3 days
6. **Roll out to all Pro+ salons** via batch update
7. **Add analytics dashboard** to track success
8. **Iterate** based on real no-show data per method

---

## 7. Tier gating (full Phase 1)

| Feature | Free | Pro | Studio | Enterprise |
|---|:---:|:---:|:---:|:---:|
| GAP 2, 6, 7, 8, 9 (basic) | ✅ | ✅ | ✅ | ✅ |
| GAP 3 (Voucher) | ✅ | ✅ | ✅ | ✅ |
| GAP 5 (Slot Ranking) | ❌ | ✅ | ✅ | ✅ |
| GAP 10 (Image Recognition) | ❌ | ✅ | ✅ | ✅ |
| GAP 4 (AI Chatbot) | ❌ | ❌ | ❌ | ✅ |
| Smart Verification 'never' mode | ✅ | ✅ | ✅ | ✅ |
| Smart Verification 'always_otp' | ✅ | ✅ | ✅ | ✅ |
| Smart Verification 'auto' mode | ❌ | ✅ | ✅ | ✅ |
| Smart Verification 'always_deposit' | ❌ | ❌ | ✅ | ✅ |

---

## 8. Definition of Phase 1 DONE

Phase 1 is fully complete when:

- [x] All 9 implemented GAPS verified in production
- [ ] Smart Verification (GAP 1 replacement) deployed and enabled on at least 2 salons
- [ ] No-show rate measured and shown to be at or below 15% across all salons
- [ ] SMS delivery success rate ≥ 95% (and failures visible to reception)
- [ ] PIPEDA compliance audit passed (image uploads + AI personalization + consent flows)
- [ ] At least 1 month of real customer usage with zero P0 bugs
- [ ] Documentation updated in `docs/` (this file, gap audit, spec doc)

---

## 9. What NOT to do

- ❌ Do NOT build separate Twilio webhook tracking (Smart Verification replaces this)
- ❌ Do NOT require both OTP and deposit on same booking
- ❌ Do NOT block booking creation on SMS failure (just record it)
- ❌ Do NOT touch existing OTP/deposit flows — reuse them
- ❌ Do NOT skip the `verification_method='vip_skip'` audit trail for VIPs
- ❌ Do NOT enable Smart Verification globally before staged rollout

---

## 10. References

- **Full spec:** `docs/NAILIQ_SMART_VERIFICATION_SPEC.md` (complete with SQL, UX, RPC code)
- **Implementation prompt:** `docs/NAILIQ_SMART_VERIFICATION_PROMPT.md` (step-by-step for Claude Code)
- **Previous brief:** `docs/NAILIQ_CLAUDE_CODE_BRIEF.md` (5 wow features, already shipped in PR #199)
- **Audit report:** `docs/PHASE1_GAP_AUDIT.md` (Claude Code's verification findings)

---

**Next action:** Build Smart Verification per `NAILIQ_SMART_VERIFICATION_PROMPT.md`. This is the ONLY remaining Phase 1 item. After it ships, NailIQ Phase 1 is 100% complete.
