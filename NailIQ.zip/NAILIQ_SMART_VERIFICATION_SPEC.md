# NailIQ — Smart Booking Verification Spec

> **Replaces:** GAP 1 (Two-phase SMS Confirmation) in `NAILIQ_PHASE1_GAPS_BRIEF.md`
> **Date:** May 22, 2026
> **Status:** Architecture decision — supersedes earlier two-phase SMS tracking approach
> **Owner decision:** Combine deposit-based and OTP-based verification using risk scoring

---

## 1. Why this replaces Two-phase SMS

The original Phase 1 brief specified "Two-phase SMS Confirmation" with Twilio webhook tracking for delivery status. Investigation revealed:

1. **NailIQ already has OTP infrastructure** (`otps`, `phone_otp_sessions` tables) — building separate webhook tracking duplicates effort
2. **OTP is stronger than delivery confirmation** — webhook says SMS was delivered to the carrier, but doesn't prove the customer saw it. OTP requires the customer to read the SMS, prove it 100%.
3. **Deposit is even stronger than OTP** for no-show prevention — financial commitment beats verification
4. **The owner already has deposit infrastructure** (`bookings.deposit_required`, `deposit_amount_cents`, `deposit_status`) — leverage what exists

The smart insight: **deposit and OTP serve the same purpose** (prevent no-show + verify legitimacy). Requiring both creates friction without added value. Combining them intelligently based on risk produces better outcomes than either alone.

---

## 2. Core principle

> **Use the lightest verification that achieves the goal.**

For each booking, choose ONE of these in priority order:

1. **Nothing** (lowest friction) — for trusted customers
2. **Deposit** (strongest commitment) — when financially viable
3. **OTP** (free, ~30 second friction) — fallback when no deposit
4. **Reject** (rarely) — for confirmed bad actors

---

## 3. Decision Logic

```
Booking submitted
  │
  ├─ Compute no_show_risk_score (existing column, 0-100)
  ├─ Read salon.booking_verification_mode
  ├─ Read client_profiles.is_vip
  ├─ Read salon.deposit_required + deposit_amount_cents
  ▼
Apply decision tree
```

### Decision tree (for `mode='auto'`)

| Customer State | Risk Score | Action |
|---|---|---|
| `is_vip = true` | Any | ✅ Confirm immediately, no friction |
| Returning customer (`visit_count >= 5`, `no_show_count = 0`) | Any | ✅ Confirm immediately |
| New customer | < 30 | ✅ Confirm immediately |
| Any | 30-69 | 🔵 OTP optional (skippable with warning) |
| Any | 70-100, deposit enabled | 💰 Require deposit (no OTP) |
| Any | 70-100, deposit disabled | 🔴 Require OTP |
| `no_show_count >= 3` | Any | 💰 Force deposit if enabled, else force OTP |

### Salon owner overrides

```sql
ALTER TABLE salons ADD COLUMN booking_verification_mode text 
NOT NULL DEFAULT 'auto'
CHECK (booking_verification_mode IN (
  'auto',           -- Smart logic above (recommended)
  'always_otp',     -- Require OTP for every booking (high security)
  'always_deposit', -- Require deposit for every booking (premium salons)
  'deposit_first',  -- Try deposit, fallback OTP if customer skips
  'never'           -- Trust everyone (lowest friction, highest risk)
));
```

---

## 4. Customer UX flows

### Flow A: No verification needed (trusted)

```
[Form] → [Slot] → [Review] → [Confirm] → ✅ Done
```

Just like today. SMS confirmation sent in background.

### Flow B: Deposit required

```
[Form] → [Slot] → [Review] → [Pay $X deposit via Stripe] → ✅ Done
```

Stripe Elements inline. Deposit applies to final bill. Refundable if cancelled >24h before.

### Flow C: OTP required (no deposit)

```
[Form] → [Slot] → [Review] → [Enter phone] → SMS sent
                                ↓
                          [Enter 6-digit code] → ✅ Done
```

### Flow D: Customer choice (risk 70-100, deposit enabled but not forced)

```
[Form] → [Slot] → [Review] → 
                     │
                     ├─ "💰 Đặt cọc $20 (nhanh, được khấu trừ vào bill)" → Flow B
                     └─ "📱 Nhập mã OTP miễn phí" → Flow C
```

Customer picks. Salon owner sees breakdown of which path customers prefer.

### Flow E: Optional OTP (risk 30-69)

```
[Form] → [Slot] → [Review] → [Confirm] 
                                ↓
                     "✅ Booking đã tạo! Nhập OTP để verify (không bắt buộc)"
                     [_____] [Skip]
```

If customer skips, booking still created but flagged `verification_method='none'`. Reception sees ⚠ icon.

---

## 5. Database schema changes

### Add to `salons`

```sql
ALTER TABLE public.salons
  ADD COLUMN booking_verification_mode text NOT NULL DEFAULT 'auto'
    CHECK (booking_verification_mode IN ('auto','always_otp','always_deposit','deposit_first','never')),
  ADD COLUMN verification_risk_threshold_otp smallint NOT NULL DEFAULT 30
    CHECK (verification_risk_threshold_otp BETWEEN 0 AND 100),
  ADD COLUMN verification_risk_threshold_deposit smallint NOT NULL DEFAULT 70
    CHECK (verification_risk_threshold_deposit BETWEEN 0 AND 100);

COMMENT ON COLUMN public.salons.booking_verification_mode IS
  'Booking verification strategy: auto=smart logic, always_otp/always_deposit=force, deposit_first=try deposit first, never=no verification';

COMMENT ON COLUMN public.salons.verification_risk_threshold_otp IS
  'In auto mode, risk score >= this triggers optional OTP (default 30)';

COMMENT ON COLUMN public.salons.verification_risk_threshold_deposit IS
  'In auto mode, risk score >= this triggers required deposit (default 70)';
```

### Add to `bookings`

```sql
ALTER TABLE public.bookings
  ADD COLUMN verification_method text
    CHECK (verification_method IS NULL OR verification_method IN ('none','otp','deposit','both','vip_skip')),
  ADD COLUMN verification_completed_at timestamptz,
  ADD COLUMN otp_session_id uuid REFERENCES public.phone_otp_sessions(id) ON DELETE SET NULL,
  ADD COLUMN sms_confirmation_sent_at timestamptz,
  ADD COLUMN sms_confirmation_failed_at timestamptz,
  ADD COLUMN sms_confirmation_error text;

CREATE INDEX idx_bookings_verification_pending
  ON public.bookings(salon_id, created_at DESC)
  WHERE verification_method IS NULL AND status = 'pending';

CREATE INDEX idx_bookings_sms_failed
  ON public.bookings(salon_id, created_at DESC)
  WHERE sms_confirmation_failed_at IS NOT NULL;

COMMENT ON COLUMN public.bookings.verification_method IS
  'How this booking was verified: none=trusted/skipped, otp=phone verified, deposit=paid, both=rare, vip_skip=VIP customer';

COMMENT ON COLUMN public.bookings.sms_confirmation_sent_at IS
  'When Twilio accepted the confirmation SMS. Used by reception to spot delivery failures.';
```

---

## 6. RPC functions to add

### `determine_booking_verification` (called before showing review screen)

```sql
CREATE OR REPLACE FUNCTION public.determine_booking_verification(
  p_salon_id uuid,
  p_client_phone text,
  p_service_ids uuid[],
  p_subtotal_cents int
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_salon record;
  v_client record;
  v_risk_score int;
  v_deposit_required boolean := false;
  v_deposit_amount_cents int := 0;
  v_action text;
BEGIN
  SELECT booking_verification_mode, verification_risk_threshold_otp,
         verification_risk_threshold_deposit, deposit_required,
         deposit_high_value_cents, deposit_default_amount_cents
  INTO v_salon
  FROM salons
  WHERE id = p_salon_id;

  SELECT is_vip, visit_count, no_show_count
  INTO v_client
  FROM client_profiles
  WHERE phone = p_client_phone AND salon_id = p_salon_id;

  -- VIP bypass
  IF v_client.is_vip = true THEN
    RETURN jsonb_build_object(
      'action', 'none',
      'reason', 'vip_skip',
      'risk_score', 0
    );
  END IF;

  -- Compute risk score (simplified)
  v_risk_score := compute_no_show_risk(
    coalesce(v_client.no_show_count, 0),
    coalesce(v_client.visit_count, 0),
    p_subtotal_cents
  );

  -- Apply mode
  CASE v_salon.booking_verification_mode
    WHEN 'never' THEN
      v_action := 'none';
    WHEN 'always_otp' THEN
      v_action := 'otp_required';
    WHEN 'always_deposit' THEN
      v_action := 'deposit_required';
      v_deposit_required := true;
      v_deposit_amount_cents := coalesce(v_salon.deposit_default_amount_cents, p_subtotal_cents * 30 / 100);
    WHEN 'deposit_first' THEN
      IF v_risk_score >= v_salon.verification_risk_threshold_otp THEN
        v_action := 'deposit_or_otp';
        v_deposit_amount_cents := coalesce(v_salon.deposit_default_amount_cents, p_subtotal_cents * 30 / 100);
      ELSE
        v_action := 'none';
      END IF;
    ELSE  -- 'auto'
      IF v_risk_score < v_salon.verification_risk_threshold_otp THEN
        v_action := 'none';
      ELSIF v_risk_score < v_salon.verification_risk_threshold_deposit THEN
        v_action := 'otp_optional';
      ELSE
        -- High risk: deposit preferred, OTP fallback
        IF p_subtotal_cents >= coalesce(v_salon.deposit_high_value_cents, 5000) THEN
          v_action := 'deposit_required';
          v_deposit_required := true;
          v_deposit_amount_cents := coalesce(v_salon.deposit_default_amount_cents, p_subtotal_cents * 30 / 100);
        ELSE
          v_action := 'otp_required';
        END IF;
      END IF;
  END CASE;

  RETURN jsonb_build_object(
    'action', v_action,
    'risk_score', v_risk_score,
    'deposit_required', v_deposit_required,
    'deposit_amount_cents', v_deposit_amount_cents,
    'reason', 
      CASE v_action
        WHEN 'none' THEN 'low_risk_or_trusted'
        WHEN 'otp_optional' THEN 'medium_risk'
        WHEN 'otp_required' THEN 'high_risk_no_deposit'
        WHEN 'deposit_required' THEN 'high_risk_high_value'
        WHEN 'deposit_or_otp' THEN 'customer_choice'
        ELSE 'salon_policy'
      END
  );
END;
$$;
```

### `compute_no_show_risk` (already in spec, simplified version)

```sql
CREATE OR REPLACE FUNCTION public.compute_no_show_risk(
  p_no_show_count int,
  p_visit_count int,
  p_subtotal_cents int
) RETURNS int
LANGUAGE plpgsql
IMMUTABLE
AS $$
DECLARE
  v_score int := 30;  -- baseline for new customer
BEGIN
  -- No-show history dominates
  IF p_no_show_count >= 3 THEN v_score := v_score + 40;
  ELSIF p_no_show_count = 2 THEN v_score := v_score + 30;
  ELSIF p_no_show_count = 1 THEN v_score := v_score + 20;
  END IF;

  -- Visit count reduces risk
  IF p_visit_count = 0 THEN v_score := v_score + 15;
  ELSIF p_visit_count >= 10 THEN v_score := v_score - 25;
  ELSIF p_visit_count >= 5 THEN v_score := v_score - 15;
  ELSIF p_visit_count >= 2 THEN v_score := v_score - 5;
  END IF;

  -- High-value bookings: customer less likely to no-show on expensive booking
  IF p_subtotal_cents >= 15000 THEN v_score := v_score - 10;
  END IF;

  RETURN greatest(0, least(100, v_score));
END;
$$;
```

### `confirm_booking_with_otp` (called after customer enters OTP)

```sql
CREATE OR REPLACE FUNCTION public.confirm_booking_with_otp(
  p_booking_id uuid,
  p_otp_session_id uuid
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_session record;
  v_booking record;
BEGIN
  -- Verify OTP session valid
  SELECT * INTO v_session
  FROM phone_otp_sessions
  WHERE id = p_otp_session_id
    AND consumed_at IS NOT NULL
    AND expires_at > now();
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'otp_invalid_or_expired');
  END IF;

  -- Verify booking phone matches OTP phone
  SELECT * INTO v_booking
  FROM bookings
  WHERE id = p_booking_id
    AND client_phone = v_session.phone;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'phone_mismatch');
  END IF;

  -- Update booking
  UPDATE bookings
  SET status = 'confirmed',
      verification_method = 'otp',
      verification_completed_at = now(),
      otp_session_id = p_otp_session_id,
      confirmed_at = now()
  WHERE id = p_booking_id;

  -- Audit log
  INSERT INTO booking_events (booking_id, salon_id, event_type, payload)
  VALUES (
    p_booking_id,
    v_booking.salon_id,
    'verified_via_otp',
    jsonb_build_object('otp_session_id', p_otp_session_id)
  );

  RETURN jsonb_build_object('ok', true, 'booking_id', p_booking_id);
END;
$$;
```

---

## 7. Frontend components

### Booking flow integration

After service selection + time pick, before final confirm:

```typescript
// app/[salon]/book/review/page.tsx
const verification = await rpc('determine_booking_verification', {
  p_salon_id, p_client_phone, p_service_ids, p_subtotal_cents
});

switch (verification.action) {
  case 'none':
    return <SimpleConfirmButton />;
  case 'otp_optional':
    return <ConfirmWithOptionalOtp />;
  case 'otp_required':
    return <OtpVerificationStep mandatory />;
  case 'deposit_required':
    return <StripeDepositCheckout amount={verification.deposit_amount_cents} />;
  case 'deposit_or_otp':
    return <ChooseVerificationMethod 
      depositAmount={verification.deposit_amount_cents} />;
}
```

### Reception dashboard alerts

```typescript
// components/reception/BookingCard.tsx
{booking.sms_confirmation_failed_at && (
  <Badge variant="warning">
    ⚠ SMS không gửi được
    <Tooltip>{booking.sms_confirmation_error}</Tooltip>
  </Badge>
)}

{booking.verification_method === 'none' && booking.no_show_risk_score >= 70 && (
  <Badge variant="caution">
    ⚠ Khách rủi ro cao chưa verify
    <Button onClick={callCustomer}>Gọi xác nhận</Button>
  </Badge>
)}

{booking.verification_method === 'deposit' && (
  <Badge variant="success">
    💰 Đã đặt cọc ${booking.deposit_amount_cents / 100}
  </Badge>
)}

{booking.verification_method === 'otp' && (
  <Badge variant="info">
    ✅ Đã verify OTP
  </Badge>
)}
```

### Owner analytics

```typescript
// app/admin/analytics/verification/page.tsx
- Total bookings by verification_method (last 30 days)
- No-show rate by verification_method
- Conversion drop-off: viewed review → completed verification
- Revenue from deposits (uplift vs. no verification)
- SMS delivery success rate (sent vs failed)
```

---

## 8. Tier gating

| Feature | Free | Pro | Studio | Enterprise |
|---|:---:|:---:|:---:|:---:|
| Mode 'never' | ✅ | ✅ | ✅ | ✅ |
| Mode 'always_otp' | ✅ | ✅ | ✅ | ✅ |
| Mode 'auto' (smart logic) | ❌ | ✅ | ✅ | ✅ |
| Mode 'always_deposit' | ❌ | ❌ | ✅ | ✅ |
| Mode 'deposit_first' | ❌ | ❌ | ✅ | ✅ |
| Custom risk thresholds | ❌ | ❌ | ✅ | ✅ |
| Verification analytics | ❌ | View only | View + export | + AI optimization |

Free tier defaults to `never` (no friction, no protection).
Pro+ defaults to `auto` (smart, balanced).

---

## 9. Acceptance criteria

- [ ] `determine_booking_verification` RPC returns correct action for all combinations
- [ ] VIP customers never see OTP or deposit prompts
- [ ] Risk score < 30 → no verification
- [ ] Risk score 30-69 → OTP optional
- [ ] Risk score 70-100 + high-value → deposit
- [ ] Risk score 70-100 + low-value → OTP required
- [ ] Customer with `no_show_count >= 3` → force deposit/OTP
- [ ] OTP screen reuses existing `phone_otp_sessions` flow
- [ ] Deposit screen uses existing Stripe Connect flow
- [ ] SMS confirmation tracked: `sms_confirmation_sent_at`, `failed_at`, `error`
- [ ] Reception dashboard shows SMS failures + verification status badges
- [ ] Owner can switch mode via salon settings page
- [ ] Pro+ tier defaults to 'auto', Free defaults to 'never'
- [ ] Analytics page shows no-show rate by verification method
- [ ] Booking attempt logged even if customer abandons verification
- [ ] Pending bookings (no verification) auto-released after 15 min (free up soft_hold)

---

## 10. Migration path from current state

**Step 1:** Add columns (non-breaking, all nullable/default)
**Step 2:** Deploy `determine_booking_verification` RPC
**Step 3:** Deploy frontend with feature flag `smart_verification_enabled=false` on all salons
**Step 4:** Enable for 1 test salon (THAO VY), monitor 7 days
**Step 5:** Enable for all Pro+ salons via batch update
**Step 6:** Add analytics dashboard
**Step 7:** Iterate based on real no-show data per method

---

## 11. Why this is better than original Two-phase SMS

| Concern | Two-phase SMS | Smart Verification |
|---|---|---|
| Knows if customer received SMS | After 2 min timeout (✅ but slow) | OTP: instant (✅✅), Deposit: yes (✅✅) |
| Prevents fake/wrong phone | ❌ Just confirms delivery | ✅ Customer must enter code OR pay |
| Reduces no-show | Modest (5-10%) | Strong (40-70% reduction for high-risk) |
| Adds friction for trusted customers | None | None (VIP/repeat bypass) |
| Owner control | Limited | Full granular control |
| Differentiation vs. Booksy/Square | None (commodity feature) | Strong (smart auto mode) |
| Twilio cost | Same | Same or lower (no SMS for deposit) |
| Implementation complexity | Medium (webhook + Realtime) | Low (reuse existing OTP + deposit) |

---

**End of spec. This document replaces the GAP 1 section in `NAILIQ_PHASE1_GAPS_BRIEF.md`.**
