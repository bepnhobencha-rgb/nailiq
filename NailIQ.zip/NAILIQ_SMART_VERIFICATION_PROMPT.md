# NailIQ — Implement Smart Booking Verification

**Replaces:** the standalone Gap 1 fix (Two-phase SMS tracking via Twilio webhooks)

**Full spec:** `docs/NAILIQ_SMART_VERIFICATION_SPEC.md`

---

## Why this replaces Two-phase SMS

After verification audit, we discovered NailIQ already has OTP infrastructure (`otps`, `phone_otp_sessions`) AND deposit infrastructure (`bookings.deposit_*`). Building separate Twilio delivery tracking is duplicate effort. **OTP and deposit both serve the same purpose** (prevent no-show + verify customer), so we combine them based on risk score.

---

## Core idea

Use the LIGHTEST verification that achieves the goal:

| Customer | Verification |
|---|---|
| VIP / Repeat (5+ visits, 0 no-shows) | None |
| New + low risk (<30) | None |
| Medium risk (30-69) | OTP optional (skippable) |
| High risk (70+) + high-value booking | Deposit required |
| High risk (70+) + low-value booking | OTP required |
| Bad history (3+ no-shows) | Force deposit or OTP |

Customer NEVER needs both OTP and deposit — they serve the same purpose.

---

## Build steps

### Step 1: Database migration

```sql
-- Add to salons
ALTER TABLE salons
  ADD COLUMN booking_verification_mode text NOT NULL DEFAULT 'auto'
    CHECK (booking_verification_mode IN ('auto','always_otp','always_deposit','deposit_first','never')),
  ADD COLUMN verification_risk_threshold_otp smallint NOT NULL DEFAULT 30,
  ADD COLUMN verification_risk_threshold_deposit smallint NOT NULL DEFAULT 70;

-- Add to bookings
ALTER TABLE bookings
  ADD COLUMN verification_method text
    CHECK (verification_method IS NULL OR verification_method IN ('none','otp','deposit','both','vip_skip')),
  ADD COLUMN verification_completed_at timestamptz,
  ADD COLUMN otp_session_id uuid REFERENCES phone_otp_sessions(id) ON DELETE SET NULL,
  ADD COLUMN sms_confirmation_sent_at timestamptz,
  ADD COLUMN sms_confirmation_failed_at timestamptz,
  ADD COLUMN sms_confirmation_error text;

CREATE INDEX idx_bookings_sms_failed
  ON bookings(salon_id, created_at DESC)
  WHERE sms_confirmation_failed_at IS NOT NULL;
```

### Step 2: Build RPC functions

- `compute_no_show_risk(no_show_count, visit_count, subtotal_cents)` — returns 0-100
- `determine_booking_verification(salon_id, client_phone, service_ids, subtotal_cents)` — returns `{action, risk_score, deposit_required, deposit_amount_cents, reason}`
- `confirm_booking_with_otp(booking_id, otp_session_id)` — finalizes booking after OTP verified

See spec section 6 for full SQL.

### Step 3: Update booking flow

After service + slot selection, before final confirm:

```typescript
const verification = await rpc('determine_booking_verification', {...});

switch (verification.action) {
  case 'none': return <ConfirmButton />;
  case 'otp_optional': return <ConfirmWithSkippableOtp />;
  case 'otp_required': return <OtpStep mandatory />;
  case 'deposit_required': return <StripeDeposit amount={...} />;
  case 'deposit_or_otp': return <ChooseDepositOrOtp />;
}
```

### Step 4: Fix the original SMS gap (lightweight)

In `submitPublicBooking.ts`, change `sendSmsReminder()` from fire-and-forget to awaited:

```typescript
const smsResult = await sendSmsReminder(...);
await updateBooking(bookingId, {
  sms_confirmation_sent_at: smsResult.ok ? new Date() : null,
  sms_confirmation_failed_at: smsResult.ok ? null : new Date(),
  sms_confirmation_error: smsResult.ok ? null : smsResult.error,
});
```

Do NOT block booking creation on SMS failure — just record it.

### Step 5: Reception dashboard

Show badges on booking cards:
- `⚠ SMS không gửi được` if `sms_confirmation_failed_at IS NOT NULL`
- `💰 Đã đặt cọc $X` if `verification_method = 'deposit'`
- `✅ Đã verify OTP` if `verification_method = 'otp'`
- `⚠ Chưa verify (risk cao)` if `verification_method = 'none' AND no_show_risk_score >= 70`

### Step 6: Owner settings page

Add verification mode selector to salon settings:

```
Verification Mode:
  ( ) Trust everyone (no friction, highest risk)
  (•) Smart auto (recommended) — risk-based OTP/deposit
  ( ) Always OTP (medium friction, free)
  ( ) Always deposit (high friction, premium feel)
  ( ) Deposit first, OTP fallback

Risk Thresholds (advanced):
  OTP threshold: [30] (risk score that triggers optional OTP)
  Deposit threshold: [70] (risk score that triggers required deposit)
```

### Step 7: Analytics page

Show:
- No-show rate by verification_method (last 30 days)
- Conversion drop-off by verification step
- SMS delivery success rate (sent vs failed)
- Revenue from deposits

### Step 8: Cron job for pending bookings

```typescript
// Every 5 minutes: release pending bookings that haven't verified within 15 min
DELETE FROM bookings
WHERE status = 'pending'
  AND verification_method IS NULL
  AND created_at < NOW() - INTERVAL '15 minutes';
```

This frees the soft_hold so other customers can grab the slot.

---

## Tier gating

| Mode | Free | Pro | Studio | Enterprise |
|---|:---:|:---:|:---:|:---:|
| 'never' | ✅ | ✅ | ✅ | ✅ |
| 'always_otp' | ✅ | ✅ | ✅ | ✅ |
| 'auto' | ❌ | ✅ | ✅ | ✅ |
| 'always_deposit' | ❌ | ❌ | ✅ | ✅ |
| 'deposit_first' | ❌ | ❌ | ✅ | ✅ |
| Custom thresholds | ❌ | ❌ | ✅ | ✅ |

Default mode: Free → `never`, Pro+ → `auto`.

---

## Constraints

- Do NOT block booking on SMS failure (just record it)
- Do NOT require both OTP and deposit (they serve the same purpose)
- Do NOT touch the existing `phone_otp_sessions` flow — reuse it
- Do NOT skip OTP for VIP customers without recording `verification_method='vip_skip'`
- VIP bypass MUST be explicit in the booking record (for audit + analytics)

---

## Acceptance criteria

- [ ] All 5 decision tree paths tested end-to-end on staging
- [ ] VIP customer never sees OTP or deposit
- [ ] Reception dashboard surfaces SMS failures
- [ ] Owner can change mode via settings
- [ ] Analytics page shows no-show rate per method
- [ ] Cron releases abandoned pending bookings after 15 min
- [ ] No regression on existing booking flow (run E2E suite)
- [ ] Tier gating enforced (Free can't access 'auto' mode)

---

## Deploy strategy

1. Migrate database
2. Deploy code with feature flag `smart_verification_enabled=false` on all salons
3. Enable on THAO VY only, monitor 7 days
4. Enable on LIAM NAILS, monitor 3 days
5. Roll out to all Pro+ salons

Track: no-show rate before/after, conversion impact, SMS cost.

---

**Read `docs/NAILIQ_SMART_VERIFICATION_SPEC.md` for full specification including UX flows, SQL, and rationale. Start with Step 1 (Database migration) and stop for review before Step 2.**
